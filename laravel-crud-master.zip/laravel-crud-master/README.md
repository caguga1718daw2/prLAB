# laravel-crud
Complete Laravel 5.3 CRUD with Authentification

## Demo : 
https://demo.halimlardjane.com/laravel-crud

**The access infos:**

Email address: admin@gmail.com

Password: 123456



![alt tag](https://github.com/halimus/laravel-crud/blob/master/public/images/mpd2.jpg)


Very nice example for everybody who is beginner in Laravel like me ;)

first thing :

###Step 1 : Use Composer to install dependencies

    cd /path/to/laravel-crud

    composer install
    
###Step 2: Create Database
   Create Database in Your local MySQL (choose name), And configure that name in your .env file.
   
###Step 3 Run migrations

    >php artisan migrate

###Start Accessing the Demo





